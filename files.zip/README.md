# مدير مجموعة الأنمي 🎬

منصة ويب تفاعلية لإدارة مجموعتك من الأنمي ورفع المستندات والفيديوهات.

## الميزات ✨

- ➕ إضافة أنمي جديد
- 📄 رفع مستندات (PDF, Word, Excel)
- 🎥 رفع فيديوهات
- 💾 حفظ تلقائي للبيانات
- 🗑️ حذف آمن للملفات

## التثبيت المحلي 🖥️

```bash
# استنساخ المشروع
git clone https://github.com/YOUR_USERNAME/anime-manager.git
cd anime-manager

# تثبيت المتطلبات
npm install

# تشغيل التطبيق محلياً
npm run dev
```

زيارة: http://localhost:3000

## النشر على Vercel 🚀

### الخطوة 1: إنشاء حساب GitHub
- اذهب إلى https://github.com
- اضغط "Sign up" وأنشئ حساب

### الخطوة 2: رفع الملفات
```bash
# في المجلد الذي تم نسخ الملفات إليه
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/anime-manager.git
git push -u origin main
```

### الخطوة 3: نشر على Vercel
1. اذهب إلى https://vercel.com
2. اضغط "Login" ثم "Continue with GitHub"
3. اختر repository `anime-manager`
4. اضغط "Deploy"
5. سيتم النشر تلقائياً! 🎉

### الخطوة 4: الوصول إلى الموقع
بعد النشر، ستحصل على رابط مثل:
```
https://anime-manager-xxxxx.vercel.app
```

هذا هو موقعك الجديد! 🌐

## الدعم 📞

للمساعدة أو الإبلاغ عن مشاكل، تواصل معنا.
